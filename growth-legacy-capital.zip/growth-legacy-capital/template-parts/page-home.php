<?php
/*
This template is used fo Home Page
Template Name: Home Page Template
*/
get_header();
?>
<!-- Hero Section -->
<?php
$selected_container = get_theme_mod('home_container_toggle', 'main_home');
$hero_section = get_field('main_hero_section');
$hero_form_group = get_field('hero_form_group');

if ($selected_container === 'main_home' && $hero_section) :
    $background_image = !empty($hero_section['background_image']['url']) ? esc_url($hero_section['background_image']['url']) : '';
    $hero_title = !empty($hero_section['hero_title']) ? esc_html($hero_section['hero_title']) : '';
    $sub_title = !empty($hero_section['sub_title']) ? esc_html($hero_section['sub_title']) : '';
    $button_text = !empty($hero_section['hero_button_text']) ? esc_html($hero_section['hero_button_text']) : '';
    $button_link = !empty($hero_section['hero_button_link']['url']) ? esc_url($hero_section['hero_button_link']['url']) : '';

    if ($background_image || $hero_title || $sub_title || $button_text || $button_link) :
?>
        <div class="main-container">
            <!-- Hero Section -->
            <section class="hero-section"
                <?php if ($background_image) : ?>
                style="background: url('<?php echo $background_image; ?>'); background-size: cover; background-position: center; background-repeat: no-repeat;"
                <?php endif; ?>>
                <div class="container">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-10 col-md-8 col-lg-7 hero-right align-items-center d-flex">
                            <div class="hero-text">
                                <?php if ($hero_title) : ?>
                                    <h1 class="hero-title"><?php echo $hero_title; ?></h1>
                                <?php endif; ?>

                                <?php if ($sub_title) : ?>
                                    <p class="hero-subtitle"><?php echo $sub_title; ?></p>
                                <?php endif; ?>

                                <?php if ($button_text && $button_link) : ?>
                                    <a href="<?php echo $button_link; ?>" class="btn btn-primary hero-button">
                                        <?php echo $button_text; ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php
    endif;
else:
    if ($hero_form_group) :
        $form_title = !empty($hero_form_group['title']) ? esc_html($hero_form_group['title']) : '';
        $form_description = !empty($hero_form_group['description']) ? $hero_form_group['description'] : '';
        $form_shortcode = !empty($hero_form_group['form_shortcode']) ? $hero_form_group['form_shortcode'] : '';
        $ebook_image = !empty($hero_form_group['ebook_image']['url']) ? esc_url($hero_form_group['ebook_image']['url']) : '';

        if ($form_title || $form_description || $form_shortcode || $ebook_image) :
        ?>
            <div class="form-container">
                <!-- Hero Section 2 -->
                <section class="hero-section-2">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-12 hero-section2-title m-0">
                                <?php if ($form_title) : ?>
                                    <h2 class="hero-section2-main-title"><?php echo $form_title; ?></h2>
                                <?php endif; ?>

                                <?php if ($form_description) : ?>
                                    <p class="hero-section2-subtitle"><?php echo $form_description; ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row form-row">
                            <?php if ($form_shortcode) : ?>
                                <div class="col-12 col-md-8 mt-4 hero-section2-form">
                                    <?php echo do_shortcode($form_shortcode); ?>
                                </div>
                            <?php endif; ?>

                            <?php if ($ebook_image) : ?>
                                <div class="col-12 col-md-4 hero-section2-image">
                                    <img src="<?php echo $ebook_image; ?>" alt="Wealth Building Kit" class="hero-section2-img">
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </section>
            </div>
<?php
        endif;
    endif;
endif;
?>

<!-- New Section -->
<?php
$about_section = get_field('about_section');
if ($about_section && (!empty($about_section['title']) || !empty($about_section['description']))) :
?>
    <section class="about-section">
        <div class="container">
            <div class="row">
                <div class="col-12 about-text">
                    <?php if (!empty($about_section['title'])) : ?>
                        <h2 class="about-title"><?php echo esc_html($about_section['title']); ?></h2>
                    <?php endif; ?>

                    <?php if (!empty($about_section['description'])) : ?>
                        <?php echo wp_kses_post($about_section['description']); ?>
                    <?php endif; ?>

                    <div class="about-icons d-flex gap-3 justify-content-center">
                        <div class="icon-separator"></div>
                        <div class="icon-separator"></div>
                        <div class="icon-separator"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<!-- Stats Section -->
<?php
$stats_group = get_field('stats_group');
if ($stats_group) :
    $background = !empty($stats_group['section_background']) ? $stats_group['section_background']['url'] : 'https://dev-glcdemo.pantheonsite.io/wp-content/uploads/2025/02/state-background.png';
?>
    <section class="stats-section" style="background: url('<?php echo esc_url($background); ?>'); background-size: cover; background-position: center; background-repeat: no-repeat;">
        <div class="container stats-container">
            <div class="row">
                <?php if (!empty($stats_group['icon_1']) || !empty($stats_group['icon_1_title']) || !empty($stats_group['icon_1_number'])) : ?>
                    <div class="col-12 col-md-4">
                        <div class="stat-box">
                            <?php if (!empty($stats_group['icon_1'])) : ?>
                                <img src="<?php echo esc_url($stats_group['icon_1']['url']); ?>" alt="<?php echo esc_attr($stats_group['icon_1_title']); ?>" class="stat-icon">
                            <?php endif; ?>
                            <?php if (!empty($stats_group['icon_1_title'])) : ?>
                                <h3 class="stat-title"><?php echo esc_html($stats_group['icon_1_title']); ?></h3>
                            <?php endif; ?>
                            <?php if (!empty($stats_group['icon_1_number'])) : ?>
                                <p class="stat-value"><?php echo esc_html($stats_group['icon_1_number']); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($stats_group['icon_2_']) || !empty($stats_group['icon_2_title']) || !empty($stats_group['icon_2_number'])) : ?>
                    <div class="col-12 col-md-4">
                        <div class="stat-box">
                            <?php if (!empty($stats_group['icon_2_'])) : ?>
                                <img src="<?php echo esc_url($stats_group['icon_2_']['url']); ?>" alt="<?php echo esc_attr($stats_group['icon_2_title']); ?>" class="stat-icon">
                            <?php endif; ?>
                            <?php if (!empty($stats_group['icon_2_title'])) : ?>
                                <h3 class="stat-title"><?php echo esc_html($stats_group['icon_2_title']); ?></h3>
                            <?php endif; ?>
                            <?php if (!empty($stats_group['icon_2_number'])) : ?>
                                <p class="stat-value"><?php echo esc_html($stats_group['icon_2_number']); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($stats_group['icon_3']) || !empty($stats_group['icon_3_title']) || !empty($stats_group['icon_3_number'])) : ?>
                    <div class="col-12 col-md-4">
                        <div class="stat-box">
                            <?php if (!empty($stats_group['icon_3'])) : ?>
                                <img src="<?php echo esc_url($stats_group['icon_3']['url']); ?>" alt="<?php echo esc_attr($stats_group['icon_3_title']); ?>" class="stat-icon">
                            <?php endif; ?>
                            <?php if (!empty($stats_group['icon_3_title'])) : ?>
                                <h3 class="stat-title"><?php echo esc_html($stats_group['icon_3_title']); ?></h3>
                            <?php endif; ?>
                            <?php if (!empty($stats_group['icon_3_number'])) : ?>
                                <p class="stat-value"><?php echo esc_html($stats_group['icon_3_number']); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>


<?php
$why_invest = get_field('why_invest_section');
if ($why_invest): ?>
    <!-- Why Invest Section -->
    <section class="why-invest-section">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <?php if (!empty($why_invest['section_heading'])): ?>
                        <h2 class="why-invest-title"><?php echo esc_html($why_invest['section_heading']); ?></h2>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <?php if (!empty($why_invest['icon_1']) && !empty($why_invest['icon_1_title']) && !empty($why_invest['icon_1_description'])): ?>
                    <div class="col-12 col-md-4">
                        <div class="invest-box invest-text">
                            <img src="<?php echo esc_url($why_invest['icon_1']['url']); ?>" alt="<?php echo esc_attr($why_invest['icon_1_title']); ?>" class="invest-icon">
                            <h4 class="invest-title"><?php echo esc_html($why_invest['icon_1_title']); ?></h4>
                            <?php echo wp_kses_post($why_invest['icon_1_description']); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($why_invest['icon_2']) && !empty($why_invest['icon_2_title']) && !empty($why_invest['icon_2_description'])): ?>
                    <div class="col-12 col-md-4">
                        <div class="invest-box invest-text">
                            <img src="<?php echo esc_url($why_invest['icon_2']['url']); ?>" alt="<?php echo esc_attr($why_invest['icon_2_title']); ?>" class="invest-icon">
                            <h4 class="invest-title"><?php echo esc_html($why_invest['icon_2_title']); ?></h4>
                            <?php echo wp_kses_post($why_invest['icon_2_description']); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($why_invest['icon_3']) && !empty($why_invest['icon_3_title']) && !empty($why_invest['icon_3_description'])): ?>
                    <div class="col-12 col-md-4">
                        <div class="invest-box invest-text">
                            <img src="<?php echo esc_url($why_invest['icon_3']['url']); ?>" alt="<?php echo esc_attr($why_invest['icon_3_title']); ?>" class="invest-icon">
                            <h4 class="invest-title"><?php echo esc_html($why_invest['icon_3_title']); ?></h4>
                            <?php echo wp_kses_post($why_invest['icon_3_description']); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($why_invest['icon_4']) && !empty($why_invest['icon_4_title']) && !empty($why_invest['icon_4_description'])): ?>
                    <div class="col-12 col-md-4">
                        <div class="invest-box invest-text">
                            <img src="<?php echo esc_url($why_invest['icon_4']['url']); ?>" alt="<?php echo esc_attr($why_invest['icon_4_title']); ?>" class="invest-icon">
                            <h4 class="invest-title"><?php echo esc_html($why_invest['icon_4_title']); ?></h4>
                            <?php echo wp_kses_post($why_invest['icon_4_description']); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($why_invest['icon_5']) && !empty($why_invest['icon_5_title']) && !empty($why_invest['icon_5_description'])): ?>
                    <div class="col-12 col-md-4">
                        <div class="invest-box invest-text">
                            <img src="<?php echo esc_url($why_invest['icon_5']['url']); ?>" alt="<?php echo esc_attr($why_invest['icon_5_title']); ?>" class="invest-icon">
                            <h4 class="invest-title"><?php echo esc_html($why_invest['icon_5_title']); ?></h4>
                            <?php echo wp_kses_post($why_invest['icon_5_description']); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($why_invest['icon_6']) && !empty($why_invest['icon_6_title']) && !empty($why_invest['icon_6_description'])): ?>
                    <div class="col-12 col-md-4">
                        <div class="invest-box invest-text">
                            <img src="<?php echo esc_url($why_invest['icon_6']['url']); ?>" alt="<?php echo esc_attr($why_invest['icon_6_title']); ?>" class="invest-icon">
                            <h4 class="invest-title"><?php echo esc_html($why_invest['icon_6_title']); ?></h4>
                            <?php echo wp_kses_post($why_invest['icon_6_description']); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

<?php endif; ?>

<?php
$faqs = get_field('faqs_section');
if ($faqs): ?>
    <!-- FAQ Section -->
    <section class="faq-section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <?php if (!empty($faqs['section_heading'])): ?>
                        <h2 class="faq-title"><?php echo esc_html($faqs['section_heading']); ?></h2>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-6 col-lg-6">
                    <?php if (!empty($faqs['faq_1']) && !empty($faqs['faq_1_description'])): ?>
                        <div class="faq-item">
                            <h4 class="faq-question"><span class="faq-start">Q:</span> <?php echo esc_html($faqs['faq_1']); ?></h4>
                            <?php echo wp_kses_post($faqs['faq_1_description']); ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($faqs['faq_2']) && !empty($faqs['faq_2_description'])): ?>
                        <div class="faq-item">
                            <h4 class="faq-question"><span class="faq-start">Q:</span> <?php echo esc_html($faqs['faq_2']); ?></h4>
                            <?php echo wp_kses_post($faqs['faq_2_description']); ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($faqs['faq_3']) && !empty($faqs['faq_3_description'])): ?>
                        <div class="faq-item">
                            <h4 class="faq-question"><span class="faq-start">Q:</span> <?php echo esc_html($faqs['faq_3']); ?></h4>
                            <?php echo wp_kses_post($faqs['faq_3_description']); ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($faqs['faq_4']) && !empty($faqs['faq_4_description'])): ?>
                        <div class="faq-item">
                            <h4 class="faq-question"><span class="faq-start">Q:</span> <?php echo esc_html($faqs['faq_4']); ?></h4>
                            <?php echo wp_kses_post($faqs['faq_4_description']); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($faqs['faq_5']) && !empty($faqs['faq_5_description'])): ?>
                        <div class="faq-item">
                            <h4 class="faq-question"><span class="faq-start">Q:</span> <?php echo esc_html($faqs['faq_5']); ?></h4>
                            <?php echo wp_kses_post($faqs['faq_5_description']); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-12 col-md-6 col-lg-6">
                    <?php if (!empty($faqs['faq_6']) && !empty($faqs['faq_6_description'])): ?>
                        <div class="faq-item">
                            <h4 class="faq-question"><span class="faq-start">Q:</span> <?php echo esc_html($faqs['faq_6']); ?></h4>
                            <?php echo wp_kses_post($faqs['faq_6_description']); ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($faqs['faq_7']) && !empty($faqs['faq_7_description'])): ?>
                        <div class="faq-item">
                            <h4 class="faq-question"><span class="faq-start">Q:</span> <?php echo esc_html($faqs['faq_7']); ?></h4>
                            <?php echo wp_kses_post($faqs['faq_7_description']); ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($faqs['faq_8']) && !empty($faqs['faq_8_description'])): ?>
                        <div class="faq-item">
                            <h4 class="faq-question"><span class="faq-start">Q:</span> <?php echo esc_html($faqs['faq_8']); ?></h4>
                            <?php echo wp_kses_post($faqs['faq_8_description']); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($faqs['faq_9']) && !empty($faqs['faq_9_description'])): ?>
                        <div class="faq-item">
                            <h4 class="faq-question"><span class="faq-start">Q:</span> <?php echo esc_html($faqs['faq_9']); ?></h4>
                            <?php echo wp_kses_post($faqs['faq_9_description']); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($faqs['faq_10']) && !empty($faqs['faq_10_description'])): ?>
                        <div class="faq-item">
                            <h4 class="faq-question"><span class="faq-start">Q:</span> <?php echo esc_html($faqs['faq_10']); ?></h4>
                            <?php echo wp_kses_post($faqs['faq_10_description']); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
$footer_form = get_field('footer_form');
if ($footer_form): ?>
    <!-- Form Section -->
    <section class="form-section">
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-column align-items-center">
                    <?php if (!empty($footer_form['title'])): ?>
                        <h4 class="form-title"><?php echo esc_html($footer_form['title']); ?></h4>
                    <?php endif; ?>

                    <?php if (!empty($footer_form['button_link']) && !empty($footer_form['button_text'])): ?>
                        <a href="<?php echo esc_url($footer_form['button_link']['url']); ?>"
                            class="btn btn-primary hero-button"
                            target="<?php echo esc_attr($footer_form['button_link']['target']); ?>">
                            <?php echo esc_html($footer_form['button_text']); ?>
                        </a>
                    <?php endif; ?>

                    <?php if (!empty($footer_form['form_shortcode'])): ?>
                        <?php echo do_shortcode($footer_form['form_shortcode']); ?>
                    <?php endif; ?>
                </div>

                <?php if (!empty($footer_form['description'])): ?>
                    <div class="col-12 d-flex flex-column align-items-center">
                        <p class="form-description"><?php echo esc_html($footer_form['description']); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
get_footer();
?>