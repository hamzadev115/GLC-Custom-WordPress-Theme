<?php
/*
This template is used fo Partners Page
Template Name: Partners Page Template
*/
get_header();
?>
<!-- Hero Section -->
<?php
$hero_banner = get_field('hero_banner');

if ($hero_banner) :
?>
    <section
        class="partner-section"
        style="
        width: 100%;
        background-image: url('<?php echo esc_url($hero_banner['url']); ?>');
        background-position: center;
        background-size: cover;
    ">
    </section>
<?php endif; ?>

<!-- Partnership Text Section -->
<?php
$about_ceo = get_field('about_ceo');
if ($about_ceo) :
    $ceo_name = $about_ceo['ceo_name'];
    $ceo_decription = $about_ceo['decription'];
    $ceo_quote = $about_ceo['ceo_quote'];
    $ceo_details = $about_ceo['ceo_details'];
    $ceo_picture = $about_ceo['ceo_picture'];
?>
    <section>
        <div class="container partnership-text">
            <div class="row py-md-5 py-3">
                <div class="col-12">
                    <?php echo wp_kses_post($ceo_decription); ?>
                </div>
            </div>
        </div>
    </section>
    <!-- Ceo Section -->
    <section>
        <div class="container ceo-details">
            <div class="row">
                <div class="col-12 col-lg-7">
                    <?php if ($ceo_name) : ?>
                        <h3 class="ceo-name"><?php echo wp_kses_post($ceo_name); ?></h3>
                    <?php endif; ?>

                    <?php if ($ceo_quote) : ?>
                        <h5 class="ceo-quote"><?php echo esc_html($ceo_quote); ?></h5>
                    <?php endif; ?>

                    <?php if ($ceo_details) : ?>
                        <?php echo wp_kses_post($ceo_details); ?>
                    <?php endif; ?>
                </div>
                <div class="col-12 col-lg-5 p-lg-5">
                    <?php if ($ceo_picture) : ?>
                        <img src="<?php echo esc_url($ceo_picture['url']); ?>" alt="<?php echo esc_attr($ceo_name); ?>" />
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<!-- Partners Section -->
<?php
$advisor_section = get_field('bord_of_advisor_section');
if ($advisor_section):
?>
    <section>
        <div class="container py-5 py-md-5">
            <div class="row">
                <div class="col-12">
                    <?php if (!empty($advisor_section['section_heading'])): ?>
                        <h2 class="board-title"><?php echo esc_html($advisor_section['section_heading']); ?></h2>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <?php if (!empty($advisor_section['advisor_1_name'])): ?>
                    <div class="col-12 col-lg-4">
                        <div class="board-image">
                            <?php
                            if (!empty($advisor_section['advisor_1_picture'])): ?>
                                <img src="<?php echo esc_url($advisor_section['advisor_1_picture']['url']); ?>" alt="<?php echo esc_attr($advisor_section['advisor_1_name']); ?>" />
                            <?php endif; ?>
                        </div>
                        <div class="board-details partner-details">
                            <h3 class="partner-name"><?php echo esc_html($advisor_section['advisor_1_name']); ?></h3>
                            <p><?php echo wp_kses_post($advisor_section['advisor_1_description']); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($advisor_section['advisor_2_name'])): ?>
                    <div class="col-12 col-lg-4">
                        <div class="board-image">
                            <?php
                            if (!empty($advisor_section['advisor_2_picture'])): ?>
                                <img src="<?php echo esc_url($advisor_section['advisor_2_picture']['url']); ?>" alt="<?php echo esc_attr($advisor_section['advisor_2_name']); ?>" />
                            <?php endif; ?>
                        </div>
                        <div class="board-details partner-details">
                            <h3 class="partner-name"><?php echo esc_html($advisor_section['advisor_2_name']); ?></h3>
                            <p><?php echo wp_kses_post($advisor_section['advisor_2_description']); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($advisor_section['advisor_3_name'])): ?>
                    <div class="col-12 col-lg-4">
                        <div class="board-image">
                            <?php
                            if (!empty($advisor_section['advisor_3_picture'])): ?>
                                <img src="<?php echo esc_url($advisor_section['advisor_3_picture']['url']); ?>" alt="<?php echo esc_attr($advisor_section['advisor_3_name']); ?>" />
                            <?php endif; ?>
                        </div>
                        <div class="board-details partner-details">
                            <h3 class="partner-name"><?php echo esc_html($advisor_section['advisor_3_name']); ?></h3>
                            <p><?php echo wp_kses_post($advisor_section['advisor_3_description']); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
$section_banner = get_field('section_banner');
$banner_url = !empty($section_banner) ? esc_url($section_banner['url']) : 'http://dev-glcdemo.pantheonsite.io/wp-content/uploads/2025/02/forth-section.png';
?>

<!-- Fourth Section -->
<section
    class="partner-section"
    style="
        width: 100%;
        height: 550px;
        background-image: url('<?php echo $banner_url; ?>');
        background-position: center;
        background-size: cover;
    ">
</section>

<!--core value-->
<?php
$core_values = get_field('core_values_section');
?>
<section>
    <div class="container">
        <div class="row pt-3 pt-md-5">
            <div class="col-12">
                <h2 class="core-title"><?php echo !empty($core_values['heading']) ? esc_html($core_values['heading']) : 'Our Core Values'; ?></h2>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-md-6 py-2 py-lg-5">
                <?php if (!empty($core_values['value_1']) && !empty($core_values['value_1_description'])) : ?>
                    <div class="core-values value-details">
                        <h4 class="value-titile"><?php echo esc_html($core_values['value_1']); ?></h4>
                        <p><?php echo esc_html($core_values['value_1_description']); ?></p>
                    </div>
                <?php endif; ?>

                <?php if (!empty($core_values['value_2']) && !empty($core_values['value_2_description'])) : ?>
                    <div class="core-values value-details">
                        <h4 class="value-titile"><?php echo esc_html($core_values['value_2']); ?></h4>
                        <p><?php echo esc_html($core_values['value_2_description']); ?></p>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-12 col-md-6 py-2 py-lg-5">
                <?php if (!empty($core_values['value_3']) && !empty($core_values['value_3_description'])) : ?>
                    <div class="core-values value-details">
                        <h4 class="value-titile"><?php echo esc_html($core_values['value_3']); ?></h4>
                        <p><?php echo esc_html($core_values['value_3_description']); ?></p>
                    </div>
                <?php endif; ?>

                <?php if (!empty($core_values['value_4']) && !empty($core_values['value_4_description'])) : ?>
                    <div class="core-values value-details">
                        <h4 class="value-titile"><?php echo esc_html($core_values['value_4']); ?></h4>
                        <p><?php echo esc_html($core_values['value_4_description']); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!--form Section-->
<?php
$form_section = get_field('form_section');
?>

<section class="form-section">
    <div class="container">
        <div class="row">
            <div class="col-12 d-flex flex-column align-items-center">
                <h4 class="form-title">
                    <?php echo !empty($form_section['heading']) ? esc_html($form_section['heading']) : 'Let’s Grow Your Wealth Together'; ?>
                </h4>

                <?php if (!empty($form_section['button_link']) && !empty($form_section['button_text'])) : ?>
                    <a href="<?php echo esc_url($form_section['button_link']['url']); ?>" class="btn btn-primary hero-button" target="<?php echo esc_attr($form_section['button_link']['target']); ?>">
                        <?php echo esc_html($form_section['button_text']); ?>
                    </a>
                <?php endif; ?>

                <?php if (!empty($form_section['form_shortcode'])) : ?>
                    <?php echo do_shortcode($form_section['form_shortcode']); ?>
                <?php endif; ?>
            </div>
            <div class="col-12 d-flex flex-column align-items-center">
                <?php if (!empty($form_section['description'])) : ?>
                    <p class="form-description"><?php echo esc_html($form_section['description']); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php
get_footer();
?>