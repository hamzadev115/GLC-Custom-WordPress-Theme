<?php
/*
This template is used fo Contact Page
Template Name: Contact Page Template
*/
get_header();
?>
<!-- Hero Section -->
<?php
// Get Hero Banner field
$hero_banner = get_field('hero_banner');

if ($hero_banner): ?>
    <section class="partner-section"
        style="
        width: 100%;
        background-image: url('<?php echo esc_url($hero_banner['url']); ?>');
        background-position: center;
        background-size: cover;
    ">
    </section>
<?php endif; ?>

<section class="py-3 py-lg-5">
    <div class="container">
        <div class="row p-2">
            <!-- Contact Form Column -->
            <?php
            // Get ACF fields
            $section_heading = get_field('section_heading');
            $form_shortcode = get_field('form_shortcode');
            ?>
            <div class="col-12 col-md-8 p-3 p-lg-5">
                <?php if ($section_heading): ?>
                    <h3 class="contact-title mb-4"><?php echo esc_html($section_heading); ?></h3>
                <?php endif; ?>
                <div class="contact-form">
                    <?php
                    if ($form_shortcode):
                        echo do_shortcode($form_shortcode);
                    endif;
                    ?>
                </div>
            </div>

            <!-- Contact Info Column -->
            <?php
            // Get ACF fields
            $heading = get_field('heading');
            $email = get_field('email');
            $email_link = get_field('email_link');
            $phone = get_field('phone');
            $phone_link = get_field('phone_link');
            $address = get_field('address');
            $address_link = get_field('address_link');
            ?>

            <div class="col-12 col-md-4 p-3 p-lg-5 rounded border">
                <?php if ($heading): ?>
                    <h3 class="contact-info-title mb-4"><?php echo esc_html($heading); ?></h3>
                <?php endif; ?>

                <div class="contact-info">
                    <!-- Email -->
                    <?php if ($email): ?>
                        <div class="info-item mb-3">
                            <h5 class="m-0"><i class="fas fa-envelope me-2"></i>Email</h5>
                            <p class="m-0 text-muted">
                                <?php if ($email_link): ?>
                                    <a href="<?php echo esc_url($email_link['url']); ?>" target="<?php echo esc_attr($email_link['target']); ?>">
                                        <?php echo esc_html($email); ?>
                                    </a>
                                <?php else: ?>
                                    <?php echo esc_html($email); ?>
                                <?php endif; ?>
                            </p>
                        </div>
                    <?php endif; ?>

                    <!-- Phone -->
                    <?php if ($phone): ?>
                        <div class="info-item mb-3">
                            <h5 class="m-0"><i class="fas fa-phone me-2"></i>Phone</h5>
                            <p class="m-0 text-muted">
                                <?php if ($phone_link): ?>
                                    <a href="<?php echo esc_url($phone_link['url']); ?>" target="<?php echo esc_attr($phone_link['target']); ?>">
                                        <?php echo esc_html($phone); ?>
                                    </a>
                                <?php else: ?>
                                    <?php echo esc_html($phone); ?>
                                <?php endif; ?>
                            </p>
                        </div>
                    <?php endif; ?>

                    <!-- Address -->
                    <?php if ($address): ?>
                        <div class="info-item">
                            <h5 class="m-0"><i class="fas fa-map-marker-alt me-2"></i>Address</h5>
                            <p class="m-0 text-muted">
                                <?php if ($address_link): ?>
                                    <a href="<?php echo esc_url($address_link['url']); ?>" target="<?php echo esc_attr($address_link['target']); ?>">
                                        <?php echo esc_html($address); ?>
                                    </a>
                                <?php else: ?>
                                    <?php echo esc_html($address); ?>
                                <?php endif; ?>
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
get_footer();
?>