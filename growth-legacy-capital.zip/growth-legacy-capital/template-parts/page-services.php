<?php
/*
This template is used fo Services Page
Template Name: Services Page Template
*/
get_header();
?>
<!-- Hero Section -->
<?php
$hero_banner = get_field('hero_banner');
$hero_banner_url = $hero_banner ? esc_url($hero_banner['url']) : '';
?>
<section class="service-hero-section" style="width: 100%; background-image: url('<?php echo $hero_banner_url; ?>'); background-position: center; background-size: cover;">
</section>

<!-- Legacy Growth Section -->
<?php
$services_section = get_field('services_section');
if ($services_section):
    $section_heading = $services_section['section_heading'] ?? '';
    $service_1_title = $services_section['service_1_title'] ?? '';
    $service_1_description = $services_section['service_1_description'] ?? '';
    $service_1_image = $services_section['service_1_image']['url'] ?? 'https://dev-glcdemo.pantheonsite.io/wp-content/uploads/2025/02/image-placeholder.png';

    $service_2_title = $services_section['service_2_title'] ?? '';
    $service_2_description = $services_section['service_2_description'] ?? '';
    $service_2_image = $services_section['service_2_image']['url'] ?? 'https://dev-glcdemo.pantheonsite.io/wp-content/uploads/2025/02/image-placeholder.png';

    $service_3_title = $services_section['service_3_title'] ?? '';
    $service_3_description = $services_section['service_3_description'] ?? '';
    $service_3_image = $services_section['service_3_image']['url'] ?? 'https://dev-glcdemo.pantheonsite.io/wp-content/uploads/2025/02/image-placeholder.png';

    $service_4_title = $services_section['service_4_title'] ?? '';
    $service_4_description = $services_section['service_4_description'] ?? '';
    $service_4_image = $services_section['service_4_image']['url'] ?? 'https://dev-glcdemo.pantheonsite.io/wp-content/uploads/2025/02/image-placeholder.png';
?>
    <section class="legacy-growth-section">
        <div class="container">
            <?php if ($section_heading): ?>
                <h2 class="service-card-head"><?php echo esc_html($section_heading); ?></h2>
            <?php endif; ?>

            <!-- Step 1 -->
            <div class="row service-card-row flex-wrap-reverse flex-wrap-md-reverse">
                <div class="col-12 col-md-8 col-lg-8 d-flex align-items-center">
                    <div class="p-4">
                        <?php if ($service_1_title): ?>
                            <h5 class="service-card-title"><span class="service-card-step">Step 1:</span> <?php echo esc_html($service_1_title); ?></h5>
                        <?php endif; ?>
                        <?php if ($service_1_description): ?>
                            <?php echo wp_kses_post($service_1_description); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4">
                    <div class="service-box-image">
                        <img src="<?php echo esc_url($service_1_image); ?>" alt="">
                    </div>
                </div>
            </div>

            <!-- Step 2 -->
            <div class="row service-card-row">
                <div class="col-12 col-md-4 col-lg-4">
                    <div class="service-box-image">
                        <img src="<?php echo esc_url($service_2_image); ?>" alt="">
                    </div>
                </div>
                <div class="col-12 col-md-8 col-lg-8 d-flex align-items-center">
                    <div class="p-4">
                        <?php if ($service_2_title): ?>
                            <h5 class="service-card-title"><span class="service-card-step">Step 2:</span> <?php echo esc_html($service_2_title); ?></h5>
                        <?php endif; ?>
                        <?php if ($service_2_description): ?>
                            <?php echo wp_kses_post($service_2_description); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Step 3 -->
            <div class="row service-card-row flex-wrap-reverse flex-wrap-md-reverse">
                <div class="col-12 col-md-8 col-lg-8 d-flex align-items-center">
                    <div class="p-4">
                        <?php if ($service_3_title): ?>
                            <h5 class="service-card-title"><span class="service-card-step">Step 3:</span> <?php echo esc_html($service_3_title); ?></h5>
                        <?php endif; ?>
                        <?php if ($service_3_description): ?>
                            <?php echo wp_kses_post($service_3_description); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4">
                    <div class="service-box-image">
                        <img src="<?php echo esc_url($service_3_image); ?>" alt="">
                    </div>
                </div>
            </div>

            <!-- Step 4 -->
            <div class="row service-card-row">
                <div class="col-12 col-md-4 col-lg-4">
                    <div class="service-box-image">
                        <img src="<?php echo esc_url($service_4_image); ?>" alt="">
                    </div>
                </div>
                <div class="col-12 col-md-8 col-lg-8 d-flex align-items-center">
                    <div class="p-4">
                        <?php if ($service_4_title): ?>
                            <h5 class="service-card-title"><span class="service-card-step">Step 4:</span> <?php echo esc_html($service_4_title); ?></h5>
                        <?php endif; ?>
                        <?php if ($service_4_description): ?>
                            <?php echo wp_kses_post($service_4_description); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<!-- Process Section Start -->
<section class="process-section">
    <div class="container">
        <div class="row">
            <div class="col-12 py-3 mb-3">
                <?php if (!empty(get_field('our_process_section')['section_heading'])) : ?>
                    <h2 class="service-card-head"><?php echo esc_html(get_field('our_process_section')['section_heading']); ?></h2>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php $section_bg = get_field('our_process_section')['section_background_image']; ?>
    <div class="container-fluid" style="width: 100%; height: auto; background-image: url('<?php echo !empty($section_bg) ? esc_url($section_bg['url']) : 'https://dev-glcdemo.pantheonsite.io/wp-content/uploads/2025/02/services-process.png'; ?>'); background-position: center; background-size: cover;">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <?php $process_image = get_field('our_process_section')['process_image']; ?>
                    <?php if (!empty($process_image)) : ?>
                        <div class="process-image">
                            <img src="<?php echo esc_url($process_image['url']); ?>" alt="">
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <?php $process_section = get_field('our_process_section'); ?>

                <div class="col-12 col-md-4">
                    <div class="process-box">
                        <?php if (!empty($process_section['icon_1'])) : ?>
                            <img src="<?php echo esc_url($process_section['icon_1']['url']); ?>" alt="Icon 1" class="process-icon">
                        <?php endif; ?>
                        <?php if (!empty($process_section['icon_1_title'])) : ?>
                            <h4 class="process-title"><?php echo esc_html($process_section['icon_1_title']); ?></h4>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-12 col-md-4">
                    <div class="process-box">
                        <?php if (!empty($process_section['icon_2'])) : ?>
                            <img src="<?php echo esc_url($process_section['icon_2']['url']); ?>" alt="Icon 2" class="process-icon">
                        <?php endif; ?>
                        <?php if (!empty($process_section['icon_2_title'])) : ?>
                            <h4 class="process-title"><?php echo esc_html($process_section['icon_2_title']); ?></h4>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-12 col-md-4">
                    <div class="process-box">
                        <?php if (!empty($process_section['icon_3'])) : ?>
                            <img src="<?php echo esc_url($process_section['icon_3']['url']); ?>" alt="Icon 3" class="process-icon">
                        <?php endif; ?>
                        <?php if (!empty($process_section['icon_3_title'])) : ?>
                            <h4 class="process-title"><?php echo esc_html($process_section['icon_3_title']); ?></h4>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!--form Section-->
<?php
$contact_section = get_field('contact_section');
if ($contact_section) :
?>
    <section class="form-section">
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-column align-items-center">
                    <?php if (!empty($contact_section['heading'])) : ?>
                        <h4 class="form-title"><?php echo esc_html($contact_section['heading']); ?></h4>
                    <?php endif; ?>

                    <?php if (!empty($contact_section['button_link']) && !empty($contact_section['button_text'])) : ?>
                        <a href="<?php echo esc_url($contact_section['button_link']['url']); ?>" class="btn btn-primary hero-button">
                            <?php echo esc_html($contact_section['button_text']); ?>
                        </a>
                    <?php endif; ?>

                    <?php if (!empty($contact_section['form_shortcode'])) : ?>
                        <?php echo do_shortcode($contact_section['form_shortcode']); ?>
                    <?php endif; ?>
                </div>

                <div class="col-12 d-flex flex-column align-items-center">
                    <?php if (!empty($contact_section['description'])) : ?>
                        <p class="form-description"><?php echo esc_html($contact_section['description']); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
get_footer();
?>