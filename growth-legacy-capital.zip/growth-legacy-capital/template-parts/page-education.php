<?php
/*
This template is used fo Education Page
Template Name: Education Page Template
*/
get_header();
?>
<?php
$hero_banner = get_field('hero_banner');
$hero_banner_url = !empty($hero_banner) ? esc_url($hero_banner['url']) : 'http://dev-glcdemo.pantheonsite.io/wp-content/uploads/2025/03/education-hero.png';
?>
<!-- Hero Section -->
<section class="partner-section"
    style="width: 100%; background-image: url('<?php echo $hero_banner_url; ?>'); background-position: center; background-size: cover;">
</section>

<!-- Returns section Section -->
<?php
$high_returns_section = get_field('high_returns_section');

$image_1 = !empty($high_returns_section['image_1']) ? esc_url($high_returns_section['image_1']['url']) : 'http://dev-glcdemo.pantheonsite.io/wp-content/uploads/2025/03/education-image1.png';
$image_2 = !empty($high_returns_section['image_2']) ? esc_url($high_returns_section['image_2']['url']) : 'http://dev-glcdemo.pantheonsite.io/wp-content/uploads/2025/03/education-image2.png';
$graph_image = !empty($high_returns_section['graph_image']) ? esc_url($high_returns_section['graph_image']['url']) : 'http://dev-glcdemo.pantheonsite.io/wp-content/uploads/2025/03/return-graph.png';

$section_heading = !empty($high_returns_section['section_heading']) ? esc_html($high_returns_section['section_heading']) : 'High Returns. Cash Flow. Tax Benefits.<br />Why Choose Between Them?';
$section_description = !empty($high_returns_section['section_description']) ? $high_returns_section['section_description'] : '<p>Multifamily investing has earned a reputation as a high-performing wealth-building tool for a lot of good reasons...</p>';
$image_caption = !empty($high_returns_section['image_caption']) ? $high_returns_section['image_caption'] : '<h5 class="return-details-a">Reid Bennett, CCIM. “Historical Returns, Stocks Versus Bonds Versus Real Estate” LinkedIn, August, 2023, <a href="#" class="custom-link">link.</a></h5>';
$image_description = !empty($high_returns_section['image_description']) ? $high_returns_section['image_description'] : '<p>Add to that the guarantee of reliable, steady monthly cash flow from renters and some impressive tax incentives...</p>';
?>

<section>
    <div class="container py-3 py-md-5">
        <div class="row">
            <div class="col-12 col-lg-4 return-section-image">
                <?php if ($image_1): ?>
                    <img src="<?php echo $image_1; ?>" alt="" />
                <?php endif; ?>
                <?php if ($image_2): ?>
                    <img src="<?php echo $image_2; ?>" alt="" />
                <?php endif; ?>
            </div>
            <div class="col-12 col-lg-8 py-3 return-details">
                <h3 class="return-title"><?php echo $section_heading; ?></h3>
                <?php echo $section_description; ?>
                <?php if ($graph_image): ?>
                    <img src="<?php echo $graph_image; ?>" alt="" class="return-graph" style="width: 100%;" />
                <?php endif; ?>
                <?php echo $image_caption; ?>
            </div>
            <div class="col-12 px-4 return-details">
                <?php echo $image_description; ?>
            </div>
        </div>
    </div>
    <div class="about-icons d-flex gap-3 justify-content-center">
        <div class="icon-separator"></div>
        <div class="icon-separator"></div>
        <div class="icon-separator"></div>
    </div>
</section>

<?php
// Get Stream Section group field
$stream_section = get_field('stream_section');

if ($stream_section): ?>
    <!-- Stream Section -->
    <section>
        <div class="container py-5 py-md-5">
            <div class="row">
                <div class="col-12">
                    <?php if (!empty($stream_section['section_heading'])): ?>
                        <h2 class="stream-title"><?php echo esc_html($stream_section['section_heading']); ?></h2>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (!empty($stream_section['card_1_title']) || !empty($stream_section['card_1_description']) || !empty($stream_section['card_1_image'])): ?>
                <div class="row align-items-center py-3">
                    <div class="col-12 col-md-8">
                        <div class="stream-details stream-card-details">
                            <?php if (!empty($stream_section['card_1_title'])): ?>
                                <h3 class="stream-card-name"><?php echo esc_html($stream_section['card_1_title']); ?></h3>
                            <?php endif; ?>
                            <?php if (!empty($stream_section['card_1_description'])): ?>
                                <?php echo wp_kses_post($stream_section['card_1_description']); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <?php if (!empty($stream_section['card_1_image'])): ?>
                            <div class="stream-card-image">
                                <img src="<?php echo esc_url($stream_section['card_1_image']['url']); ?>" alt="<?php echo esc_attr($stream_section['card_1_image']['alt']); ?>" />
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!empty($stream_section['card_2_title']) || !empty($stream_section['card_2_description']) || !empty($stream_section['card_2_image'])): ?>
                <div class="row d-flex flex-md-row-reverse align-items-center py-3">
                    <div class="col-12 col-md-8">
                        <div class="stream-details stream-card-details">
                            <?php if (!empty($stream_section['card_2_title'])): ?>
                                <h3 class="stream-card-name"><?php echo esc_html($stream_section['card_2_title']); ?></h3>
                            <?php endif; ?>
                            <?php if (!empty($stream_section['card_2_description'])): ?>
                                <?php echo wp_kses_post($stream_section['card_2_description']); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <?php if (!empty($stream_section['card_2_image'])): ?>
                            <div class="stream-card-image">
                                <img src="<?php echo esc_url($stream_section['card_2_image']['url']); ?>" alt="<?php echo esc_attr($stream_section['card_2_image']['alt']); ?>" />
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!empty($stream_section['card_3_title']) || !empty($stream_section['card_3_description']) || !empty($stream_section['card_3_image'])): ?>
                <div class="row align-items-center py-3">
                    <div class="col-12 col-md-8">
                        <div class="stream-details stream-card-details">
                            <?php if (!empty($stream_section['card_3_title'])): ?>
                                <h3 class="stream-card-name"><?php echo esc_html($stream_section['card_3_title']); ?></h3>
                            <?php endif; ?>
                            <?php if (!empty($stream_section['card_3_description'])): ?>
                                <?php echo wp_kses_post($stream_section['card_3_description']); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <?php if (!empty($stream_section['card_3_image'])): ?>
                            <div class="stream-card-image">
                                <img src="<?php echo esc_url($stream_section['card_3_image']['url']); ?>" alt="<?php echo esc_attr($stream_section['card_3_image']['alt']); ?>" />
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!empty($stream_section['card_4_title']) || !empty($stream_section['card_4_description']) || !empty($stream_section['card_4_image'])): ?>
                <div class="row flex-md-row-reverse align-items-center py-3">
                    <div class="col-12 col-md-8">
                        <div class="stream-details stream-card-details">
                            <?php if (!empty($stream_section['card_4_title'])): ?>
                                <h3 class="stream-card-name"><?php echo esc_html($stream_section['card_4_title']); ?></h3>
                            <?php endif; ?>
                            <?php if (!empty($stream_section['card_4_description'])): ?>
                                <?php echo wp_kses_post($stream_section['card_4_description']); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <?php if (!empty($stream_section['card_4_image'])): ?>
                            <div class="stream-card-image">
                                <img src="<?php echo esc_url($stream_section['card_4_image']['url']); ?>" alt="<?php echo esc_attr($stream_section['card_4_image']['alt']); ?>" />
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </section>
<?php endif; ?>

<!--form Section-->
<?php
$form_section = get_field('form_section');
if ($form_section): ?>
    <section class="form-section">
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-column align-items-center">
                    <?php if (!empty($form_section['section_heading'])): ?>
                        <h4 class="form-title"><?php echo esc_html($form_section['section_heading']); ?></h4>
                    <?php endif; ?>

                    <?php if (!empty($form_section['button_link']) && !empty($form_section['button_text'])): ?>
                        <a href="<?php echo esc_url($form_section['button_link']['url']); ?>"
                            class="btn btn-primary hero-button"
                            target="<?php echo esc_attr($form_section['button_link']['target']); ?>">
                            <?php echo esc_html($form_section['button_text']); ?>
                        </a>
                    <?php endif; ?>

                    <?php if (!empty($form_section['form_shortcode'])): ?>
                        <?php echo do_shortcode($form_section['form_shortcode']); ?>
                    <?php endif; ?>
                </div>

                <?php if (!empty($form_section['description'])): ?>
                    <div class="col-12 d-flex flex-column align-items-center">
                        <p class="form-description"><?php echo esc_html($form_section['description']); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
get_footer();
?>