<?php
require get_template_directory() . '/inc/field-group/home-group.php';
require get_template_directory() . '/inc/field-group/services-group.php';
require get_template_directory() . '/inc/field-group/partner-group.php';
require get_template_directory() . '/inc/field-group/education-group.php';
require get_template_directory() . '/inc/field-group/contact-group.php';